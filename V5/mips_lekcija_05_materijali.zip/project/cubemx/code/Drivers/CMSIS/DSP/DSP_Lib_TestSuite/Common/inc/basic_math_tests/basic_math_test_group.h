#ifndef _BASIC_MATH_TEST_GROUP_H_
#define _BASIC_MATH_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Groups */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(basic_math_tests);

#endif /* _BASIC_MATH_TEST_GROUP_H_ */
