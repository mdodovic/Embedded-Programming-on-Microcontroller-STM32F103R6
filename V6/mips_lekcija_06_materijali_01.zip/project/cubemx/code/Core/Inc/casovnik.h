/*
 * casovnik.h
 *
 *  Created on: Nov 26, 2020
 *      Author: Marko Micovic
 */

#ifndef CORE_INC_CASOVNIK_H_
#define CORE_INC_CASOVNIK_H_

#include "main.h"
#include "tim.h"
#include "gpio.h"

extern void casovnik();

#endif /* CORE_INC_CASOVNIK_H_ */
